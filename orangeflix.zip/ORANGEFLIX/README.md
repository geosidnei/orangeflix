Esta é minha leitura do Projeto CLONE DA PÁGINA INICIAL DA NETFLIX

PROFESSOR: FELIPE AGUIAR

ESCOLA: DIGITAL INNOVATION ONE

Aqui está a parte superior da página. Aproveitei imagem do meu curso de alemão, feito pela Deutsche Welle e o texto também está em alemão:

![instragam1aversao](/home/sidnei/codes/ORANGEFLIX/img/orangeflixTop.png)



Aqui vemos texto do filme principal, botões e a primeira parte do carrossel, feito no plugin Jquery, comas imagens retiradas do site The Movie DataBase (TMDB):

![instragam1aversao](/home/sidnei/codes/ORANGEFLIX/img/orangeflixDown1.png)



E  novamente o texto do filme principal, botões e a segunda parte do carrossel do plugin Jquery e mais imagens do site TMDB:

![instragam1aversao](/home/sidnei/codes/ORANGEFLIX/img/orangeflixDown2.png)